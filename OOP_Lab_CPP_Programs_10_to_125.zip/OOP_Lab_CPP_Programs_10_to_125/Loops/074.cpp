// Program 74: Print strong numbers within a range
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 074.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 74: Print strong numbers within a range\n";
    cout << "Enter the required input values: ";
    int lo,hi; cin>>lo>>hi;if(lo>hi)swap(lo,hi);for(int n=max(0,lo);n<=hi;n++){int x=n,s=0;do{int d=x%10,f=1;for(int i=2;i<=d;i++)f*=i;s+=f;x/=10;}while(x);if(s==n)cout<<n<<" ";}cout<<"\n";
    return 0;
}
