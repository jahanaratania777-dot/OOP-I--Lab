// Program 58: Count digits of a number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 058.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 58: Count digits of a number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; unsigned long long x=n<0?-(unsigned long long)n:(unsigned long long)n; int count=0; do{count++;x/=10;}while(x); cout<<"Digits = "<<count<<"\n";
    return 0;
}
