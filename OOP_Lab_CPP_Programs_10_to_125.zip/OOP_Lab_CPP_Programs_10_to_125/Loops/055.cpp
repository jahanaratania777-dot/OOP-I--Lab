// Program 55: Sum of all even numbers from 1 to N
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 055.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 55: Sum of all even numbers from 1 to N\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; long long s=0; for(int i=2;i<=n;i+=2) s+=i; cout<<"Sum = "<<s<<"\n";
    return 0;
}
