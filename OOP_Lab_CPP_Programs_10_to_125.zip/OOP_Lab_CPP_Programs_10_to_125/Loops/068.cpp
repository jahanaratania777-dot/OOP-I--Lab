// Program 68: Find LCM of two numbers
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 068.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 68: Find LCM of two numbers\n";
    cout << "Enter the required input values: ";
    long long a,b; cin>>a>>b; long long x=llabs(a),y=llabs(b),p=x,q=y; while(q){long long t=q;q=p%q;p=t;} if(x==0||y==0) cout<<"LCM = 0\n"; else cout<<"LCM = "<<(x/p)*y<<"\n";
    return 0;
}
