// Program 57: Factorial of a number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 057.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 57: Factorial of a number\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; if(n<0||n>20){cerr<<"Enter n from 0 to 20 for 64-bit factorial.\n";return 1;} unsigned long long f=1; for(int i=2;i<=n;i++) f*=i; cout<<"Factorial = "<<f<<"\n";
    return 0;
}
