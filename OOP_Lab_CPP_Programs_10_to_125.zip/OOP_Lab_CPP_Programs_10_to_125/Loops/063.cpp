// Program 63: Check prime number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 063.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 63: Check prime number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; bool prime=n>=2; for(long long i=2;prime&&i<=n/i;i++) if(n%i==0) prime=false; cout<<(prime?"Prime\n":"Not prime\n");
    return 0;
}
