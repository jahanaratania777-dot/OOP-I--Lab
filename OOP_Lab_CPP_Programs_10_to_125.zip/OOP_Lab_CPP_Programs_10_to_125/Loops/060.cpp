// Program 60: Product of digits of a number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 060.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 60: Product of digits of a number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; unsigned long long x=n<0?-(unsigned long long)n:(unsigned long long)n; int p=1; do{p*=x%10;x/=10;}while(x); cout<<"Product of digits = "<<p<<"\n";
    return 0;
}
