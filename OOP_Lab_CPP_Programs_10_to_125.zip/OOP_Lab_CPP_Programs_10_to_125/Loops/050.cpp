// Program 50: Print numbers from N to 1
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 050.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 50: Print numbers from N to 1\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=n;i>=1;i--) cout<<i<<" "; cout<<"\n";
    return 0;
}
