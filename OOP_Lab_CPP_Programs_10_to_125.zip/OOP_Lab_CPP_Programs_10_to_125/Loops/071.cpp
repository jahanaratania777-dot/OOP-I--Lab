// Program 71: Check perfect number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 071.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 71: Check perfect number\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; if(n<=1){cout<<"Not perfect\n";return 0;} int sum=1; for(int i=2;i<=n/i;i++)if(n%i==0){sum+=i;if(i!=n/i)sum+=n/i;} cout<<(sum==n?"Perfect\n":"Not perfect\n");
    return 0;
}
