// Program 72: Print perfect numbers within a range
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 072.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 72: Print perfect numbers within a range\n";
    cout << "Enter the required input values: ";
    int lo,hi; cin>>lo>>hi; if(lo>hi)swap(lo,hi); for(int n=max(2,lo);n<=hi;n++){int s=1;for(int d=2;d<=n/d;d++)if(n%d==0){s+=d;if(d!=n/d)s+=n/d;}if(s==n)cout<<n<<" ";} cout<<"\n";
    return 0;
}
