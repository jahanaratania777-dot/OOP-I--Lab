// Program 65: Generate Fibonacci series
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 065.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 65: Generate Fibonacci series\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; long long a=0,b=1; for(int i=0;i<n;i++){cout<<a<<" "; if(i<n-1){if(LLONG_MAX-a<b){cerr<<"Overflow\n";return 1;} long long c=a+b;a=b;b=c;}} cout<<"\n";
    return 0;
}
