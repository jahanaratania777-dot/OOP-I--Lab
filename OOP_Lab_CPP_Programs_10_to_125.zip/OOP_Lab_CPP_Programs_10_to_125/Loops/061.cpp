// Program 61: Reverse a number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 061.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 61: Reverse a number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; long long x=n, r=0; while(x!=0){int d=x%10; if(r>LLONG_MAX/10||r<LLONG_MIN/10){cerr<<"Reversed value overflow\n";return 1;} r=r*10+d; x/=10;} cout<<"Reverse = "<<r<<"\n";
    return 0;
}
