// Program 62: Check palindrome number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 062.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 62: Check palindrome number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; if(n<0){cout<<"Not palindrome\n";return 0;} long long x=n,r=0; do{r=r*10+x%10;x/=10;}while(x); cout<<(r==n?"Palindrome\n":"Not palindrome\n");
    return 0;
}
