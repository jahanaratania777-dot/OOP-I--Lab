// Program 70: Print Armstrong numbers within a range
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 070.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 70: Print Armstrong numbers within a range\n";
    cout << "Enter the required input values: ";
    int lo,hi; cin>>lo>>hi; if(lo>hi) swap(lo,hi); for(int n=max(0,lo);n<=hi;n++){int d=to_string(n).size(),x=n; long long s=0;do{int v=x%10;s+=(long long)round(pow(v,d));x/=10;}while(x);if(s==n)cout<<n<<" ";} cout<<"\n";
    return 0;
}
