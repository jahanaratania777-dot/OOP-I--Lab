// Program 51: Print all even numbers from 1 to N
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 051.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 51: Print all even numbers from 1 to N\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=2;i<=n;i+=2) cout<<i<<" "; cout<<"\n";
    return 0;
}
