// Program 67: Find GCD of two numbers
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 067.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 67: Find GCD of two numbers\n";
    cout << "Enter the required input values: ";
    long long a,b; cin>>a>>b; a=llabs(a);b=llabs(b); while(b){long long t=b;b=a%b;a=t;} cout<<"GCD = "<<a<<"\n";
    return 0;
}
