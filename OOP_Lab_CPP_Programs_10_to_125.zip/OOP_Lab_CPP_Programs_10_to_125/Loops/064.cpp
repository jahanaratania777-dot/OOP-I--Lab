// Program 64: Print prime numbers from 1 to N and count them
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 064.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 64: Print prime numbers from 1 to N and count them\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; int count=0; for(int x=2;x<=n;x++){bool p=true;for(int d=2;d<=x/d;d++)if(x%d==0){p=false;break;}if(p){cout<<x<<" ";count++;}} cout<<"\nCount = "<<count<<"\n";
    return 0;
}
