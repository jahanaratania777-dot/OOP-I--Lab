// Program 54: Sum of numbers from 1 to N
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 054.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 54: Sum of numbers from 1 to N\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; long long s=0; for(int i=1;i<=n;i++) s+=i; cout<<"Sum = "<<s<<"\n";
    return 0;
}
