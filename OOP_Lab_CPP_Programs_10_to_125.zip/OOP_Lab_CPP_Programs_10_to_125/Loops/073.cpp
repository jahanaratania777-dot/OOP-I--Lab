// Program 73: Check strong number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 073.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 73: Check strong number\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; if(n<0){cout<<"Not strong\n";return 0;} int x=n,s=0; do{int d=x%10,f=1;for(int i=2;i<=d;i++)f*=i;s+=f;x/=10;}while(x); cout<<(s==n?"Strong\n":"Not strong\n");
    return 0;
}
