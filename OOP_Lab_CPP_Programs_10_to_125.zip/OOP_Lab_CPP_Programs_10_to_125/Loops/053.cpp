// Program 53: Print multiplication table of a number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 053.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 53: Print multiplication table of a number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; for(int i=1;i<=10;i++) cout<<n<<" x "<<i<<" = "<<n*i<<"\n";
    return 0;
}
