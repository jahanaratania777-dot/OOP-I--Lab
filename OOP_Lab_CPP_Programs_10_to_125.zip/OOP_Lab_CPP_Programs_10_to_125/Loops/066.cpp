// Program 66: Find power of a number using a loop
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 066.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 66: Find power of a number using a loop\n";
    cout << "Enter the required input values: ";
    double base; int exp; cin>>base>>exp; if(exp<0){cout<<"Negative exponent is not supported in this integer-loop exercise.\n";return 0;} double result=1; for(int i=0;i<exp;i++) result*=base; cout<<"Result = "<<result<<"\n";
    return 0;
}
