// Program 69: Check Armstrong number
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 069.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 69: Check Armstrong number\n";
    cout << "Enter the required input values: ";
    long long n; cin>>n; if(n<0){cout<<"Not Armstrong\n";return 0;} long long x=n; int digits=0; do{digits++;x/=10;}while(x); x=n; long long sum=0; do{int d=x%10;sum+=(long long)round(pow(d,digits));x/=10;}while(x); cout<<(sum==n?"Armstrong\n":"Not Armstrong\n");
    return 0;
}
