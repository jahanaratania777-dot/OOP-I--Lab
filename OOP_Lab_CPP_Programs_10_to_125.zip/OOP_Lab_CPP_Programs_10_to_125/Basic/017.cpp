// Program 17: Area of a rectangle
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 017.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 17: Area of a rectangle\n";
    cout << "Enter the required input values: ";
    double l,w; cout<<"Length and width: "; cin>>l>>w;
cout<<"Area = "<<l*w<<"\n";
    return 0;
}
