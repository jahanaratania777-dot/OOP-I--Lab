// Program 12: Percentage of five subjects
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 012.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 12: Percentage of five subjects\n";
    cout << "Enter the required input values: ";
    double marks[5], total=0; cout<<"Enter marks of five subjects (each out of 100): ";
for(double &x:marks){cin>>x; total+=x;}
cout<<"Percentage = "<<total/5.0<<"%\n";
    return 0;
}
