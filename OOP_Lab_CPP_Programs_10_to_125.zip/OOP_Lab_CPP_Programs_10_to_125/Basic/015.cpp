// Program 15: Area of a circle
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 015.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 15: Area of a circle\n";
    cout << "Enter the required input values: ";
    const double PI=acos(-1.0); double r; cout<<"Radius: "; cin>>r;
if(r<0){cerr<<"Radius cannot be negative.\n"; return 1;} cout<<"Area = "<<PI*r*r<<"\n";
    return 0;
}
