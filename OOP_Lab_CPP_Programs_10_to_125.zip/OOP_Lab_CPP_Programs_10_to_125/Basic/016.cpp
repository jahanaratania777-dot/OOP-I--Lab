// Program 16: Area of a triangle
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 016.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 16: Area of a triangle\n";
    cout << "Enter the required input values: ";
    double b,h; cout<<"Base and height: "; cin>>b>>h;
cout<<"Area = "<<0.5*b*h<<"\n";
    return 0;
}
