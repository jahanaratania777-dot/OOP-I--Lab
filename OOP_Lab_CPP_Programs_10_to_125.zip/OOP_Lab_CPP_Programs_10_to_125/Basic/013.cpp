// Program 13: Celsius to Fahrenheit
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 013.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 13: Celsius to Fahrenheit\n";
    cout << "Enter the required input values: ";
    double c; cout<<"Temperature in Celsius: "; cin>>c;
cout<<"Fahrenheit = "<<(c*9.0/5.0+32)<<"\n";
    return 0;
}
