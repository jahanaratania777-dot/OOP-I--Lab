// Program 18: Perimeter of a rectangle
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 018.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 18: Perimeter of a rectangle\n";
    cout << "Enter the required input values: ";
    double l,w; cout<<"Length and width: "; cin>>l>>w;
cout<<"Perimeter = "<<2*(l+w)<<"\n";
    return 0;
}
