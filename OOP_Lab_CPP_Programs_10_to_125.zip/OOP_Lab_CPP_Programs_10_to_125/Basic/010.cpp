// Program 10: Swap two numbers without a third variable
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 010.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 10: Swap two numbers without a third variable\n";
    cout << "Enter the required input values: ";
    long long a,b; cout<<"Enter two integers: "; cin>>a>>b;
a=a+b; b=a-b; a=a-b; cout<<"After swap: a="<<a<<", b="<<b<<"\n";
    return 0;
}
