// Program 11: Average of three numbers
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 011.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 11: Average of three numbers\n";
    cout << "Enter the required input values: ";
    double a,b,c; cout<<"Enter three numbers: "; cin>>a>>b>>c;
cout<<"Average = "<<(a+b+c)/3.0<<"\n";
    return 0;
}
