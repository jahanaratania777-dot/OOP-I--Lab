// Program 14: Fahrenheit to Celsius
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 014.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 14: Fahrenheit to Celsius\n";
    cout << "Enter the required input values: ";
    double f; cout<<"Temperature in Fahrenheit: "; cin>>f;
cout<<"Celsius = "<<((f-32)*5.0/9.0)<<"\n";
    return 0;
}
