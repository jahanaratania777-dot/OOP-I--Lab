// Program 20: Compound interest
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 020.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 20: Compound interest\n";
    cout << "Enter the required input values: ";
    double p,r,t; int n; cout<<"Principal, annual rate (%), years, compounds per year: "; cin>>p>>r>>t>>n;
if(n<=0){cerr<<"Compounding frequency must be positive.\n"; return 1;}
double amount=p*pow(1+r/(100.0*n),n*t); cout<<"Amount = "<<amount<<"\nInterest = "<<amount-p<<"\n";
    return 0;
}
