// Program 22: Convert days into years, months and days (365-day year, 30-day month)
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 022.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 22: Convert days into years, months and days (365-day year, 30-day month)\n";
    cout << "Enter the required input values: ";
    int d; cout<<"Number of days: "; cin>>d; if(d<0){cerr<<"Enter non-negative days.\n";return 1;}
cout<<d/365<<" year(s), "<<(d%365)/30<<" month(s), "<<(d%365)%30<<" day(s)\n";
    return 0;
}
