// Program 24: Calculate electricity bill
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 024.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 24: Calculate electricity bill\n";
    cout << "Enter the required input values: ";
    double units, bill=0; cout<<"Units consumed: "; cin>>units; if(units<0){cerr<<"Units cannot be negative.\n";return 1;}
double x=units; double a=min(x,50.0); bill+=a*0.50; x-=a; a=min(x,100.0); bill+=a*0.75; x-=a; a=min(x,100.0); bill+=a*1.20; x-=a; bill+=x*1.50;
cout<<"Electricity bill = "<<bill<<" (sample slabs: first 50 @0.50, next 100 @0.75, next 100 @1.20, rest @1.50)\n";
    return 0;
}
