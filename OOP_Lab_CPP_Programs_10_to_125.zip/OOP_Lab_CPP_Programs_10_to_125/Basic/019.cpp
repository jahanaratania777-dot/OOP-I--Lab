// Program 19: Simple interest
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 019.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 19: Simple interest\n";
    cout << "Enter the required input values: ";
    double p,r,t; cout<<"Principal, annual rate (%), time (years): "; cin>>p>>r>>t;
cout<<"Simple interest = "<<p*r*t/100.0<<"\n";
    return 0;
}
