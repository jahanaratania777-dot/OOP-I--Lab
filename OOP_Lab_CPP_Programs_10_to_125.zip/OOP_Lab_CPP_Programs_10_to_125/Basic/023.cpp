// Program 23: Calculate gross salary
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 023.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 23: Calculate gross salary\n";
    cout << "Enter the required input values: ";
    double basic, hra, da; cout<<"Basic salary, HRA (%), DA (%): "; cin>>basic>>hra>>da;
cout<<"Gross salary = "<<basic*(1+(hra+da)/100.0)<<"\n";
    return 0;
}
