// Program 21: Convert seconds into hours, minutes and seconds
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 021.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 21: Convert seconds into hours, minutes and seconds\n";
    cout << "Enter the required input values: ";
    long long s; cout<<"Seconds: "; cin>>s; if(s<0){cerr<<"Enter non-negative seconds.\n";return 1;}
cout<<s/3600<<" hour(s), "<<(s%3600)/60<<" minute(s), "<<s%60<<" second(s)\n";
    return 0;
}
