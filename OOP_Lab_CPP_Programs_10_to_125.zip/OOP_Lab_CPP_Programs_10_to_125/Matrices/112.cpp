// Program 112: Multiply two matrices
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 112.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 112: Multiply two matrices\n";
    cout << "Enter the required input values: ";
    int r1,c1,r2,c2;cin>>r1>>c1;vector<vector<long long>>a(r1,vector<long long>(c1));for(auto&row:a)for(auto&x:row)cin>>x;cin>>r2>>c2;vector<vector<long long>>b(r2,vector<long long>(c2));for(auto&row:b)for(auto&x:row)cin>>x;if(c1!=r2){cout<<"Incompatible dimensions\n";return 0;}vector<vector<long long>>z(r1,vector<long long>(c2));for(int i=0;i<r1;i++)for(int j=0;j<c2;j++)for(int k=0;k<c1;k++)z[i][j]+=a[i][k]*b[k][j];for(auto row:z){for(auto x:row)cout<<x<<" ";cout<<"\n";}
    return 0;
}
