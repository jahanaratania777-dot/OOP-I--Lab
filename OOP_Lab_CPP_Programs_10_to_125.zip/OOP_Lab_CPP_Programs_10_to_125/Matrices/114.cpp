// Program 114: Find sum of all elements of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 114.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 114: Find sum of all elements of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;long long s=0;for(int i=0;i<r*c;i++){long long x;cin>>x;s+=x;}cout<<"Sum = "<<s<<"\n";
    return 0;
}
