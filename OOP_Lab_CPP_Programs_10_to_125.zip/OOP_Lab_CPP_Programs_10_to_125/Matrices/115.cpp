// Program 115: Find maximum element of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 115.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 115: Find maximum element of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;long long x,m;cin>>m;for(int i=1;i<r*c;i++){cin>>x;m=max(m,x);}cout<<"Maximum = "<<m<<"\n";
    return 0;
}
