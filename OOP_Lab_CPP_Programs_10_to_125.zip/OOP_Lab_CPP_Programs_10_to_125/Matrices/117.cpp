// Program 117: Find sum of the main diagonal
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 117.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 117: Find sum of the main diagonal\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;long long s=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++){long long x;cin>>x;if(i==j)s+=x;}cout<<"Main diagonal sum = "<<s<<"\n";
    return 0;
}
