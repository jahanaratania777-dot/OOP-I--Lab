// Program 111: Subtract two matrices
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 111.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 111: Subtract two matrices\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;vector<vector<long long>>a(r,vector<long long>(c)),b=a;for(auto&row:a)for(auto&x:row)cin>>x;for(auto&row:b)for(auto&x:row)cin>>x;for(int i=0;i<r;i++){for(int j=0;j<c;j++)cout<<a[i][j]-b[i][j]<<" ";cout<<"\n";}
    return 0;
}
