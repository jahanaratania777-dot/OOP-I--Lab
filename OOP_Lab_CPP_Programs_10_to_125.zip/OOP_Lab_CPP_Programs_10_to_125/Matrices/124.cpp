// Program 124: Find sum of each row of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 124.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 124: Find sum of each row of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;for(int i=0;i<r;i++){long long s=0;for(int j=0;j<c;j++){long long x;cin>>x;s+=x;}cout<<"Row "<<i+1<<" sum = "<<s<<"\n";}
    return 0;
}
