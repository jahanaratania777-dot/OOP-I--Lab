// Program 122: Check whether a matrix is lower triangular (duplicate item)
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 122.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 122: Check whether a matrix is lower triangular (duplicate item)\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;bool ok=true;for(int i=0;i<n;i++)for(int j=0;j<n;j++){long long x;cin>>x;if(i<j&&x!=0)ok=false;}cout<<(ok?"Lower triangular\n":"Not lower triangular\n");
    return 0;
}
