// Program 109: Input and display a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 109.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 109: Input and display a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;vector<vector<long long>>a(r,vector<long long>(c));for(auto&row:a)for(auto&x:row)cin>>x;for(auto row:a){for(auto x:row)cout<<x<<" ";cout<<"\n";}
    return 0;
}
