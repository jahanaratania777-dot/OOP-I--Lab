// Program 123: Count zero and non-zero elements of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 123.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 123: Count zero and non-zero elements of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;int z=0,nz=0;for(int i=0;i<r*c;i++){long long x;cin>>x;(x==0?z:nz)++;}cout<<"Zero = "<<z<<", Non-zero = "<<nz<<"\n";
    return 0;
}
