// Program 116: Find minimum element of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 116.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 116: Find minimum element of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;long long x,m;cin>>m;for(int i=1;i<r*c;i++){cin>>x;m=min(m,x);}cout<<"Minimum = "<<m<<"\n";
    return 0;
}
