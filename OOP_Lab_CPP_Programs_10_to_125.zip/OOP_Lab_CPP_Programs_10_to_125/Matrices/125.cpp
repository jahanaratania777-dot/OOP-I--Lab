// Program 125: Find sum of each column of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 125.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 125: Find sum of each column of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;vector<long long>s(c);for(int i=0;i<r;i++)for(int j=0;j<c;j++){long long x;cin>>x;s[j]+=x;}for(int j=0;j<c;j++)cout<<"Column "<<j+1<<" sum = "<<s[j]<<"\n";
    return 0;
}
