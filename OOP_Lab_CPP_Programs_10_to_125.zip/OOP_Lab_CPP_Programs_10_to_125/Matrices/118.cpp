// Program 118: Find sum of the secondary diagonal
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 118.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 118: Find sum of the secondary diagonal\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;long long s=0;for(int i=0;i<n;i++)for(int j=0;j<n;j++){long long x;cin>>x;if(i+j==n-1)s+=x;}cout<<"Secondary diagonal sum = "<<s<<"\n";
    return 0;
}
