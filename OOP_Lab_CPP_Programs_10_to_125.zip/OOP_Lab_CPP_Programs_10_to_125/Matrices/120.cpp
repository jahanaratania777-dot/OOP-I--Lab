// Program 120: Check whether a matrix is symmetric
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 120.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 120: Check whether a matrix is symmetric\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<vector<long long>>a(n,vector<long long>(n));for(auto&row:a)for(auto&x:row)cin>>x;bool ok=true;for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(a[i][j]!=a[j][i])ok=false;cout<<(ok?"Symmetric\n":"Not symmetric\n");
    return 0;
}
