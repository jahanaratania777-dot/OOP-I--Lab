// Program 113: Find transpose of a matrix
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 113.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 113: Find transpose of a matrix\n";
    cout << "Enter the required input values: ";
    int r,c;cin>>r>>c;vector<vector<long long>>a(r,vector<long long>(c));for(auto&row:a)for(auto&x:row)cin>>x;for(int j=0;j<c;j++){for(int i=0;i<r;i++)cout<<a[i][j]<<" ";cout<<"\n";}
    return 0;
}
