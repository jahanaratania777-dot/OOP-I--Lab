// Program 83: Print a hollow triangle pattern
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 083.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 83: Print a hollow triangle pattern\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=1;i<=n;i++){for(int j=1;j<=i;j++)cout<<(i==n||j==1||j==i?"*":" ");cout<<"\n";}
    return 0;
}
