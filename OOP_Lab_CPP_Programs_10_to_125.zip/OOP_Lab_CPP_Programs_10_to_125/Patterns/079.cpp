// Program 79: Print Floyd's triangle
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 079.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 79: Print Floyd's triangle\n";
    cout << "Enter the required input values: ";
    int n,v=1; cin>>n; for(int i=1;i<=n;i++){for(int j=1;j<=i;j++)cout<<v++<<" ";cout<<"\n";}
    return 0;
}
