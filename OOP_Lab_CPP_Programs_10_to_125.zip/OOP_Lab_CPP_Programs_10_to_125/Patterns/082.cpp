// Program 82: Print a hollow diamond pattern
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 082.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 82: Print a hollow diamond pattern\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=1;i<=n;i++){for(int s=0;s<n-i;s++)cout<<" ";for(int j=1;j<=2*i-1;j++)cout<<(j==1||j==2*i-1?"*":" ");cout<<"\n";}for(int i=n-1;i>=1;i--){for(int s=0;s<n-i;s++)cout<<" ";for(int j=1;j<=2*i-1;j++)cout<<(j==1||j==2*i-1?"*":" ");cout<<"\n";}
    return 0;
}
