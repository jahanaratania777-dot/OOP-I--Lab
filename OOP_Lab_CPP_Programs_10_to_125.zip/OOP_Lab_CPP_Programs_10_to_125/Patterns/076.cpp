// Program 76: Print a pyramid pattern
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 076.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 76: Print a pyramid pattern\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=1;i<=n;i++){for(int s=0;s<n-i;s++)cout<<" ";for(int j=0;j<2*i-1;j++)cout<<"*";cout<<"\n";}
    return 0;
}
