// Program 81: Print a diamond pattern
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 081.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 81: Print a diamond pattern\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=1;i<=n;i++){for(int s=0;s<n-i;s++)cout<<" ";for(int j=0;j<2*i-1;j++)cout<<"*";cout<<"\n";}for(int i=n-1;i>=1;i--){for(int s=0;s<n-i;s++)cout<<" ";for(int j=0;j<2*i-1;j++)cout<<"*";cout<<"\n";}
    return 0;
}
