// Program 80: Print Pascal's triangle
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 080.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 80: Print Pascal's triangle\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; for(int i=0;i<n;i++){long long v=1;for(int s=0;s<n-i-1;s++)cout<<" ";for(int j=0;j<=i;j++){cout<<v<<" ";if(j<i)v=v*(i-j)/(j+1);}cout<<"\n";}
    return 0;
}
