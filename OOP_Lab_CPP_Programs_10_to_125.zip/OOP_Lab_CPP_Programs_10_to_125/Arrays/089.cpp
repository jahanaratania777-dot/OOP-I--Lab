// Program 89: Count even and odd elements in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 089.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 89: Count even and odd elements in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;int e=0,o=0;for(int i=0;i<n;i++){long long x;cin>>x;(x%2==0?e:o)++;}cout<<"Even = "<<e<<", Odd = "<<o<<"\n";
    return 0;
}
