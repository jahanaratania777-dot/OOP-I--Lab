// Program 85: Find sum of array elements
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 085.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 85: Find sum of array elements\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; vector<long long>a(n); long long s=0;for(auto &x:a){cin>>x;s+=x;}cout<<"Sum = "<<s<<"\n";
    return 0;
}
