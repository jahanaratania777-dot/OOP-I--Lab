// Program 87: Find maximum element of an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 087.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 87: Find maximum element of an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;if(n<=0)return 1;long long x,m;cin>>m;for(int i=1;i<n;i++){cin>>x;m=max(m,x);}cout<<"Maximum = "<<m<<"\n";
    return 0;
}
