// Program 84: Input and display elements of an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 084.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 84: Input and display elements of an array\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; if(n<1||n>10000)return 1; vector<long long>a(n); for(auto &x:a)cin>>x; for(auto x:a)cout<<x<<" "; cout<<"\n";
    return 0;
}
