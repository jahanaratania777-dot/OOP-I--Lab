// Program 93: Merge two arrays
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 093.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 93: Merge two arrays\n";
    cout << "Enter the required input values: ";
    int n,m;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;cin>>m;vector<long long>b(m);for(auto&x:b)cin>>x;a.insert(a.end(),b.begin(),b.end());for(auto x:a)cout<<x<<" ";cout<<"\n";
    return 0;
}
