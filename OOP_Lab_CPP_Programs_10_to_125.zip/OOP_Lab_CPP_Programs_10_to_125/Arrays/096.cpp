// Program 96: Find frequency of each element in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 096.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 96: Find frequency of each element in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;map<long long,int>f;for(int i=0;i<n;i++){long long x;cin>>x;f[x]++;}for(auto [x,c]:f)cout<<x<<" occurs "<<c<<" time(s)\n";
    return 0;
}
