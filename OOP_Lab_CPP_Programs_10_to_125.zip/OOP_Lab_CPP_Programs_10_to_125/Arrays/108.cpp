// Program 108: Find last occurrence of an element
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 108.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 108: Find last occurrence of an element\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;long long key;cin>>key;auto it=find(a.rbegin(),a.rend(),key);if(it==a.rend())cout<<"Not found\n";else cout<<"Last position = "<<n-(it-a.rbegin())<<"\n";
    return 0;
}
