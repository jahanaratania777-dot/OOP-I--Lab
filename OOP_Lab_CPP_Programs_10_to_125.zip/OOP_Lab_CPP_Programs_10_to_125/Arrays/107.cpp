// Program 107: Find first occurrence of an element
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 107.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 107: Find first occurrence of an element\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;long long key;cin>>key;auto it=find(a.begin(),a.end(),key);if(it==a.end())cout<<"Not found\n";else cout<<"First position = "<<(it-a.begin())+1<<"\n";
    return 0;
}
