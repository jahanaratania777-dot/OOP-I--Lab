// Program 104: Perform linear search
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 104.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 104: Perform linear search\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;long long key;cin>>key;int pos=-1;for(int i=0;i<n;i++)if(a[i]==key){pos=i;break;}if(pos<0)cout<<"Not found\n";else cout<<"Found at position "<<pos+1<<"\n";
    return 0;
}
