// Program 86: Find average of array elements
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 086.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 86: Find average of array elements\n";
    cout << "Enter the required input values: ";
    int n; cin>>n; if(n<=0)return 1; vector<double>a(n);double s=0;for(auto &x:a){cin>>x;s+=x;}cout<<"Average = "<<s/n<<"\n";
    return 0;
}
