// Program 105: Perform binary search
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 105.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 105: Perform binary search\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;sort(a.begin(),a.end());long long key;cin>>key;auto it=lower_bound(a.begin(),a.end(),key);if(it==a.end()||*it!=key)cout<<"Not found\n";else cout<<"Found in sorted array at position "<<(it-a.begin())+1<<"\n";
    return 0;
}
