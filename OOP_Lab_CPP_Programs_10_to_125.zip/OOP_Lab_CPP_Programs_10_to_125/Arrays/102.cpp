// Program 102: Insert an element into an array at a position
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 102.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 102: Insert an element into an array at a position\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;int pos;long long val;cout<<"Position (1-based) and value: ";cin>>pos>>val;if(pos<1||pos>n+1){cout<<"Invalid position\n";return 0;}a.insert(a.begin()+pos-1,val);for(auto x:a)cout<<x<<" ";cout<<"\n";
    return 0;
}
