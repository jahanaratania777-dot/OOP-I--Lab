// Program 97: Find second largest element in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 097.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 97: Find second largest element in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;set<long long>s;for(int i=0;i<n;i++){long long x;cin>>x;s.insert(x);}if(s.size()<2)cout<<"No second largest distinct value\n";else{auto it=s.rbegin();++it;cout<<"Second largest = "<<*it<<"\n";}
    return 0;
}
