// Program 94: Find duplicate elements in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 094.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 94: Find duplicate elements in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;set<long long>seen,printed;for(auto x:a)if(!seen.insert(x).second)printed.insert(x);if(printed.empty())cout<<"No duplicates";else for(auto x:printed)cout<<x<<" ";cout<<"\n";
    return 0;
}
