// Program 106: Count occurrences of an element in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 106.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 106: Count occurrences of an element in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;long long key;cin>>key;cout<<"Occurrences = "<<count(a.begin(),a.end(),key)<<"\n";
    return 0;
}
