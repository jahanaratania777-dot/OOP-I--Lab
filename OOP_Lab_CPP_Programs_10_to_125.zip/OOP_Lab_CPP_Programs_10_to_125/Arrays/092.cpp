// Program 92: Copy one array into another array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 092.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 92: Copy one array into another array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n),b(n);for(auto&x:a)cin>>x;b=a;for(auto x:b)cout<<x<<" ";cout<<"\n";
    return 0;
}
