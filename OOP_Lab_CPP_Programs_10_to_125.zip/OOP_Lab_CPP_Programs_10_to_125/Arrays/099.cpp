// Program 99: Separate even and odd elements in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 099.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 99: Separate even and odd elements in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>e,o;for(int i=0;i<n;i++){long long x;cin>>x;(x%2==0?e:o).push_back(x);}cout<<"Even: ";for(auto x:e)cout<<x<<" ";cout<<"\nOdd: ";for(auto x:o)cout<<x<<" ";cout<<"\n";
    return 0;
}
