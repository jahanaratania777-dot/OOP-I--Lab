// Program 95: Remove duplicate elements from an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 095.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 95: Remove duplicate elements from an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;set<long long>s;vector<long long>b;for(auto x:a)if(s.insert(x).second)b.push_back(x);for(auto x:b)cout<<x<<" ";cout<<"\n";
    return 0;
}
