// Program 90: Count positive, negative and zero elements in an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 090.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 90: Count positive, negative and zero elements in an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;int p=0,neg=0,z=0;for(int i=0;i<n;i++){double x;cin>>x;if(x>0)p++;else if(x<0)neg++;else z++;}cout<<"Positive = "<<p<<", Negative = "<<neg<<", Zero = "<<z<<"\n";
    return 0;
}
