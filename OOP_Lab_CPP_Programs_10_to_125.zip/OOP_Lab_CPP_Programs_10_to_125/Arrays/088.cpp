// Program 88: Find minimum element of an array
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 088.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 88: Find minimum element of an array\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;if(n<=0)return 1;long long x,m;cin>>m;for(int i=1;i<n;i++){cin>>x;m=min(m,x);}cout<<"Minimum = "<<m<<"\n";
    return 0;
}
