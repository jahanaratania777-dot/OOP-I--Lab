// Program 103: Delete an element from an array at a position
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 103.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 103: Delete an element from an array at a position\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;int pos;cout<<"Position to delete (1-based): ";cin>>pos;if(pos<1||pos>n){cout<<"Invalid position\n";return 0;}a.erase(a.begin()+pos-1);for(auto x:a)cout<<x<<" ";cout<<"\n";
    return 0;
}
