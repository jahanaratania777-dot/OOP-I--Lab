// Program 100: Sort an array in ascending order
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 100.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 100: Sort an array in ascending order\n";
    cout << "Enter the required input values: ";
    int n;cin>>n;vector<long long>a(n);for(auto&x:a)cin>>x;sort(a.begin(),a.end());for(auto x:a)cout<<x<<" ";cout<<"\n";
    return 0;
}
