# OOP Lab C++ Programs (10–125)

This repository contains **116 separate C++17 source files**, one for each exercise number visible in the supplied photograph (10 through 125).

## Folder structure
- `Basic/` — 10–24
- `Decision_Making/` — 25–48
- `Loops/` — 49–74
- `Patterns/` — 75–83
- `Arrays/` — 84–108
- `Matrices/` — 109–125

## Compile and run
Each `.cpp` file is an independent program. Example:

```bash
g++ -std=c++17 Basic/010.cpp -o program
./program
```

On Windows (MinGW):

```bash
g++ -std=c++17 Basic/010.cpp -o program.exe
program.exe
```

The program prints a short prompt. Enter the values requested by that exercise. For array programs, enter `n` followed by `n` elements. For matrix programs, enter dimensions first and then matrix elements row by row (except where the program asks for two matrices).

## Notes about assumptions
The photo says “C program”; these have been implemented in **C++** as requested. Some questions do not specify rules, so the following conventional assumptions are used:
- Program 12: each of five subjects is out of 100.
- Program 22: one year = 365 days and one month = 30 days (a simple conversion convention).
- Program 24: illustrative electricity slabs are documented in the output; replace them with your course's tariff if different.
- Program 31: pass mark is 40%; Program 39 uses a clearly visible, conventional sample grade scale.
- Program 41: illustrative progressive tax slabs are documented in the output; tax rules vary by country/year.
- Program 42: admission threshold is 60 marks.
- Program 105 sorts the input first, then performs binary search; it reports the position in the sorted array.
- Program 122 repeats the lower-triangular-matrix exercise as it appears in the image.
- Pattern exercises use `*` characters; the photo is not clear enough to establish exact spacing/style for every pattern.

The image is slightly blurred. Please compare the exercise titles with your original handout before submission, especially pattern-program wording and any course-specific grading, salary, tariff, or eligibility rules.
