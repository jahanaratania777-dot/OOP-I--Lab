// Program 45: Display month name using switch-case
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 045.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 45: Display month name using switch-case\n";
    cout << "Enter the required input values: ";
    int m; cout<<"Month number (1-12): "; cin>>m; switch(m){case 1:cout<<"January";break;case 2:cout<<"February";break;case 3:cout<<"March";break;case 4:cout<<"April";break;case 5:cout<<"May";break;case 6:cout<<"June";break;case 7:cout<<"July";break;case 8:cout<<"August";break;case 9:cout<<"September";break;case 10:cout<<"October";break;case 11:cout<<"November";break;case 12:cout<<"December";break;default:cout<<"Invalid month";} cout<<"\n";
    return 0;
}
