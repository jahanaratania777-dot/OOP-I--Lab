// Program 31: Check student pass or fail
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 031.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 31: Check student pass or fail\n";
    cout << "Enter the required input values: ";
    double marks; cout<<"Enter marks (0-100): "; cin>>marks; cout<<(marks>=40&&marks<=100?"Pass\n":marks>=0&&marks<40?"Fail\n":"Invalid marks\n");
    return 0;
}
