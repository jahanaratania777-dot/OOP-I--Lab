// Program 43: Simple calculator using switch-case
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 043.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 43: Simple calculator using switch-case\n";
    cout << "Enter the required input values: ";
    double a,b; char op; cout<<"Enter expression (e.g. 8 * 2): "; cin>>a>>op>>b; switch(op){case '+':cout<<a+b;break;case '-':cout<<a-b;break;case '*':cout<<a*b;break;case '/':if(b==0){cerr<<"Cannot divide by zero\n";return 1;}cout<<a/b;break;default:cout<<"Invalid operator";} cout<<"\n";
    return 0;
}
