// Program 34: Check vowel or consonant
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 034.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 34: Check vowel or consonant\n";
    cout << "Enter the required input values: ";
    char c; cout<<"Alphabet character: "; cin>>c; c=tolower(static_cast<unsigned char>(c)); if(c<'a'||c>'z') cout<<"Not an English alphabet letter\n"; else cout<<(string("aeiou").find(c)!=string::npos?"Vowel\n":"Consonant\n");
    return 0;
}
