// Program 48: Convert digit into word using switch-case
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 048.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 48: Convert digit into word using switch-case\n";
    cout << "Enter the required input values: ";
    int d; cout<<"Digit (0-9): "; cin>>d; switch(d){case 0:cout<<"Zero";break;case 1:cout<<"One";break;case 2:cout<<"Two";break;case 3:cout<<"Three";break;case 4:cout<<"Four";break;case 5:cout<<"Five";break;case 6:cout<<"Six";break;case 7:cout<<"Seven";break;case 8:cout<<"Eight";break;case 9:cout<<"Nine";break;default:cout<<"Invalid digit";} cout<<"\n";
    return 0;
}
