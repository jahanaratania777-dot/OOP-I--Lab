// Program 35: Largest among three numbers
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 035.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 35: Largest among three numbers\n";
    cout << "Enter the required input values: ";
    double a,b,c; cout<<"Three numbers: "; cin>>a>>b>>c; cout<<"Largest = "<<max({a,b,c})<<"\n";
    return 0;
}
