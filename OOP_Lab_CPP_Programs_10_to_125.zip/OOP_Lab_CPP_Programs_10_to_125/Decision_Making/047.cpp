// Program 47: Check vowel using switch-case
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 047.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 47: Check vowel using switch-case\n";
    cout << "Enter the required input values: ";
    char c; cout<<"Character: "; cin>>c; c=tolower(static_cast<unsigned char>(c)); switch(c){case 'a':case 'e':case 'i':case 'o':case 'u':cout<<"Vowel\n";break;default:cout<<(c>='a'&&c<='z'?"Consonant\n":"Not an alphabet letter\n");}
    return 0;
}
