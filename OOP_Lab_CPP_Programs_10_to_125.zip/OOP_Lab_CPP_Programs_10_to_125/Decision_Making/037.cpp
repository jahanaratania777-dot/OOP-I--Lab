// Program 37: Largest among four numbers
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 037.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 37: Largest among four numbers\n";
    cout << "Enter the required input values: ";
    double a,b,c,d; cout<<"Four numbers: "; cin>>a>>b>>c>>d; cout<<"Largest = "<<max({a,b,c,d})<<"\n";
    return 0;
}
