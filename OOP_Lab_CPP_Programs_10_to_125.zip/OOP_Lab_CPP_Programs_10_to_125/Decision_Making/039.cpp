// Program 39: Determine grade based on marks
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 039.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 39: Determine grade based on marks\n";
    cout << "Enter the required input values: ";
    double m; cout<<"Marks (0-100): "; cin>>m; if(m<0||m>100) cout<<"Invalid marks\n"; else if(m>=80) cout<<"Grade: A+\n"; else if(m>=70) cout<<"Grade: A\n"; else if(m>=60) cout<<"Grade: A-\n"; else if(m>=50) cout<<"Grade: B\n"; else if(m>=40) cout<<"Grade: C\n"; else if(m>=33) cout<<"Grade: D\n"; else cout<<"Grade: F\n";
    return 0;
}
