// Program 46: Display number of days in a month using switch-case
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 046.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 46: Display number of days in a month using switch-case\n";
    cout << "Enter the required input values: ";
    int m,y; cout<<"Month and year: "; cin>>m>>y; switch(m){case 1:case 3:case 5:case 7:case 8:case 10:case 12:cout<<"31 days\n";break;case 4:case 6:case 9:case 11:cout<<"30 days\n";break;case 2:cout<<((y%400==0||(y%4==0&&y%100!=0))?29:28)<<" days\n";break;default:cout<<"Invalid month\n";}
    return 0;
}
