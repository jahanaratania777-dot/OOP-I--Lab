// Program 32: Check eligibility to vote
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 032.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 32: Check eligibility to vote\n";
    cout << "Enter the required input values: ";
    int age; cout<<"Age: "; cin>>age; cout<<(age>=18?"Eligible to vote\n":"Not eligible to vote\n");
    return 0;
}
