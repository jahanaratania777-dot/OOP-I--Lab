// Program 29: Find greater between two numbers
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 029.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 29: Find greater between two numbers\n";
    cout << "Enter the required input values: ";
    double a,b; cout<<"Two numbers: "; cin>>a>>b; if(a>b) cout<<a<<" is greater\n"; else if(b>a) cout<<b<<" is greater\n"; else cout<<"Both are equal\n";
    return 0;
}
