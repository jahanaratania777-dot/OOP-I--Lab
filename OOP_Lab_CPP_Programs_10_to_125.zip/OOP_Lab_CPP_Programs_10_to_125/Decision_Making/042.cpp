// Program 42: Check admission eligibility based on marks
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 042.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 42: Check admission eligibility based on marks\n";
    cout << "Enter the required input values: ";
    double m; cout<<"Admission test marks: "; cin>>m; cout<<(m>=60&&m<=100?"Eligible (minimum 60 marks)\n":m>=0&&m<60?"Not eligible\n":"Invalid marks\n");
    return 0;
}
