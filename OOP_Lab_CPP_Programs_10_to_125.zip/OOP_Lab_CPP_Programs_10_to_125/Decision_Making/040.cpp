// Program 40: Determine triangle type
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 040.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 40: Determine triangle type\n";
    cout << "Enter the required input values: ";
    double a,b,c; cout<<"Three side lengths: "; cin>>a>>b>>c; if(a<=0||b<=0||c<=0||a+b<=c||a+c<=b||b+c<=a) cout<<"Invalid triangle\n"; else if(a==b&&b==c) cout<<"Equilateral\n"; else if(a==b||a==c||b==c) cout<<"Isosceles\n"; else cout<<"Scalene\n";
    return 0;
}
