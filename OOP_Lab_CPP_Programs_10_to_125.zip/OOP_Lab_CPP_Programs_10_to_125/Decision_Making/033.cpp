// Program 33: Check leap year
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 033.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 33: Check leap year\n";
    cout << "Enter the required input values: ";
    int y; cout<<"Year: "; cin>>y; cout<<((y%400==0||(y%4==0&&y%100!=0))?"Leap year\n":"Not a leap year\n");
    return 0;
}
