// Program 28: Check divisibility by both 3 and 5
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 028.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 28: Check divisibility by both 3 and 5\n";
    cout << "Enter the required input values: ";
    long long x; cout<<"Integer: "; cin>>x; cout<<(x%3==0&&x%5==0?"Divisible by both 3 and 5\n":"Not divisible by both 3 and 5\n");
    return 0;
}
