// Program 26: Check even or odd
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 026.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 26: Check even or odd\n";
    cout << "Enter the required input values: ";
    long long x; cout<<"Integer: "; cin>>x; cout<<(x%2==0?"Even\n":"Odd\n");
    return 0;
}
