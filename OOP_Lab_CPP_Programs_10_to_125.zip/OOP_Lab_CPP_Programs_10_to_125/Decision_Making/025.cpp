// Program 25: Check positive, negative or zero
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 025.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 25: Check positive, negative or zero\n";
    cout << "Enter the required input values: ";
    double x; cout<<"Number: "; cin>>x; if(x>0) cout<<"Positive\n"; else if(x<0) cout<<"Negative\n"; else cout<<"Zero\n";
    return 0;
}
