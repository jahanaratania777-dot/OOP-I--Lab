// Program 41: Calculate income tax based on salary (sample progressive slabs)
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 041.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 41: Calculate income tax based on salary (sample progressive slabs)\n";
    cout << "Enter the required input values: ";
    double s,tax=0; cout<<"Annual taxable income: "; cin>>s; if(s<0){cerr<<"Income cannot be negative.\n";return 1;}
double rem=s; double slab=min(rem,300000.0); rem-=slab; slab=min(rem,100000.0); tax+=slab*0.05; rem-=slab; slab=min(rem,300000.0); tax+=slab*0.10; rem-=slab; slab=min(rem,400000.0); tax+=slab*0.15; rem-=slab; tax+=rem*0.20;
cout<<"Estimated tax = "<<tax<<" (illustrative slabs; replace with your course/local rules)\n";
    return 0;
}
