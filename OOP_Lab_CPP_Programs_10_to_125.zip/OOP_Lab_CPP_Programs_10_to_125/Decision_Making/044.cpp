// Program 44: Display day of week using switch-case
// OOP Lab C++ practice set. Compile with: g++ -std=c++17 044.cpp -o program
#include <bits/stdc++.h>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout << fixed << setprecision(2);
    cout << "Program 44: Display day of week using switch-case\n";
    cout << "Enter the required input values: ";
    int d; cout<<"Day number (1=Monday ... 7=Sunday): "; cin>>d; switch(d){case 1:cout<<"Monday";break;case 2:cout<<"Tuesday";break;case 3:cout<<"Wednesday";break;case 4:cout<<"Thursday";break;case 5:cout<<"Friday";break;case 6:cout<<"Saturday";break;case 7:cout<<"Sunday";break;default:cout<<"Invalid day";} cout<<"\n";
    return 0;
}
